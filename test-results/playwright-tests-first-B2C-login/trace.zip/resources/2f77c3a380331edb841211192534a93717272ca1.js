function signalAuthCompleted(dotnetHelper) {
    var authTimer = setTimeout(callNotification, 10000);

    function callNotification() {
        dotnetHelper.invokeMethodAsync("getNotifications");
    }
}
window.onFocus = (id) => {
    var maskObj = document.getElementById(id);
    maskObj.selectionStart = 0;
    maskObj.selectionEnd = 0;
} 