window.getFingerprint = async () => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    // Do a more complex drawing to increase uniqueness.
    ctx.fillStyle = 'rgb(102, 204, 0)';
    ctx.fillRect(50, 50, 50, 50);
    ctx.font = '18pt Arial';
    ctx.fillText('Kapcharge, Intrac', 2, 15);
    ctx.strokeRect(0, 0, canvas.width, canvas.height);

    const gradient = ctx.createLinearGradient(0, 0, 170, 0);
    gradient.addColorStop('0', 'magenta');
    gradient.addColorStop('0.5', 'blue');
    gradient.addColorStop('1.0', 'red');
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 5;
    ctx.strokeRect(20, 20, 150, 100);

    const canvasHash = btoa(canvas.toDataURL());

    const userAgent = navigator.userAgent;
    const language = navigator.language || navigator.userLanguage; // Adding device language
    const platform = navigator.platform; // Adding device platform
    const hardwareConcurrency = navigator.hardwareConcurrency; // Adding CPU core count
    const screenResolution = `${window.screen.width}x${window.screen.height}`;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    const dataStr = `${userAgent}-${language}-${platform}-${hardwareConcurrency}-${screenResolution}-${timezone}-${canvasHash}`;

    const hashBuffer = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(dataStr))
    let hashArray = Array.from(new Uint8Array(hashBuffer));
    let hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    return hashHex.substring(0, 250); // Return only first 250 characters
}