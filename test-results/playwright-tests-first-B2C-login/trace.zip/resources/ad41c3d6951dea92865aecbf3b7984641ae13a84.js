/* Manifest version: FV0yxxJu */
// Caution! Be sure you understand the caveats before publishing an application with
// offline support. See https://aka.ms/blazor-offline-considerations

self.importScripts('./service-worker-assets.js');
self.addEventListener('install', event => event.waitUntil(onInstall(event)));
self.addEventListener('activate', event => event.waitUntil(onActivate(event)));
self.addEventListener('fetch', event => event.respondWith(onFetch(event)));
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});

const cacheNamePrefix = 'offline-cache-';
const cacheName = `${cacheNamePrefix}${self.assetsManifest.version}`;
const offlineAssetsInclude = [ /\.dll$/, /\.pdb$/, /\.wasm/, /\.html/, /\.js$/, /\.json$/, /\.css$/, /\.woff$/, /\.png$/, /\.jpe?g$/, /\.gif$/, /\.ico$/, /\.blat$/, /\.dat$/ ];
const offlineAssetsExclude = [ 
    /^service-worker\.js$/,
    // Exclude all Syncfusion theme CSS files EXCEPT bootstrap5.css (the one we use)
    /_content\/Syncfusion\.Blazor\.Themes\/(?!bootstrap5\.css).+\.css$/
];

// CACHE BUSTING: Add version timestamp
const CACHE_VERSION = Date.now();

async function onInstall(event) {
    console.info('Service worker: Install - Version:', self.assetsManifest.version);
    
    // IMPORTANT: Immediately take control without waiting for old tabs to close
    self.skipWaiting();

    // Fetch and cache all matching items from the assets manifest
    const assetsRequests = self.assetsManifest.assets
        .filter(asset => offlineAssetsInclude.some(pattern => pattern.test(asset.url)))
        .filter(asset => !offlineAssetsExclude.some(pattern => pattern.test(asset.url)))
        .map(asset => new Request(asset.url, { 
            integrity: asset.hash, 
            cache: 'reload' // CACHE BUSTING: Force reload from network
        }));
    await caches.open(cacheName).then(cache => cache.addAll(assetsRequests));
}

async function onActivate(event) {
    console.info('Service worker: Activate - Cleaning old caches');
    
    // IMPORTANT: Immediately claim all clients
    await self.clients.claim();

    // Delete unused caches
    const cacheKeys = await caches.keys();
    await Promise.all(cacheKeys
        .filter(key => key.startsWith(cacheNamePrefix) && key !== cacheName)
        .map(key => {
            console.info('Deleting old cache:', key);
            return caches.delete(key);
        }));
}

async function onFetch(event) {
    let cachedResponse = null;
    if (event.request.method === 'GET') {
        const url = new URL(event.request.url);

        // If navigating to the technical issue static page, bypass the SPA index fallback
        if (event.request.mode === 'navigate' && url.pathname.endsWith('/technical-issue.html')) {
            // Try cache first for offline capability, then network (cache-busting prevented by new Request default)
            const cache = await caches.open(cacheName);
            const match = await cache.match('technical-issue.html');
            return match || fetch(event.request);
        }

        // Original SPA fallback logic: serve index.html for client-side routes WITHOUT file extensions
        const isNavigation = event.request.mode === 'navigate';
        const hasFileExtension = /\.[^/]+$/.test(url.pathname); // e.g. '/foo/bar.js'
        const shouldServeIndexHtml = isNavigation && !hasFileExtension;

        const request = shouldServeIndexHtml ? 'index.html' : event.request;
        const cache = await caches.open(cacheName);
        cachedResponse = await cache.match(request);
        
        // CACHE BUSTING: For HTML, CSS, and JS files, always validate with server
        if (cachedResponse && (url.pathname.endsWith('.html') || url.pathname.endsWith('.css') || url.pathname.endsWith('.js'))) {
            // Return cached version immediately but update cache in background
            fetch(event.request).then(response => {
                if (response && response.status === 200) {
                    cache.put(request, response.clone());
                }
            }).catch(() => {
                // Silently fail if network is unavailable
            });
        }
    }

    return cachedResponse || fetch(event.request);
}
