window.kpcAssistant = {
    scrollToBottom: function (element) {
        if (element) {
            element.scrollTop = element.scrollHeight;
        }
    },

    // Insert a newline at the cursor position in the textarea (called on Shift+Enter).
    insertNewline: function (cssClass) {
        const el = document.querySelector('.' + cssClass);
        if (!el) return;
        const start = el.selectionStart;
        const end   = el.selectionEnd;
        el.value = el.value.substring(0, start) + '\n' + el.value.substring(end);
        el.selectionStart = el.selectionEnd = start + 1;
        // Notify Blazor of the value change.
        el.dispatchEvent(new Event('input', { bubbles: true }));
        kpcAssistant._autoGrow(el);
    },

    // Auto-grow textarea height as the user types.
    bindAutoGrow: function (cssClass) {
        const el = document.querySelector('.' + cssClass);
        if (!el || el.__kpcGrowBound) return;
        el.__kpcGrowBound = true;
        el.addEventListener('input', function () { kpcAssistant._autoGrow(el); });
        kpcAssistant._autoGrow(el);
    },

    _autoGrow: function (el) {
        el.style.height = 'auto';
        el.style.height = Math.min(el.scrollHeight, 140) + 'px';
    },

    // Reset textarea height to single row after a message is sent.
    resetTextarea: function (cssClass) {
        const el = document.querySelector('.' + cssClass);
        if (el) { el.style.height = 'auto'; }
    },

    copy: async function (text) {
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                return true;
            }
        } catch (e) { /* fallthrough */ }

        try {
            const ta = document.createElement("textarea");
            ta.value = text;
            ta.style.position = "fixed";
            ta.style.opacity = "0";
            document.body.appendChild(ta);
            ta.select();
            const ok = document.execCommand("copy");
            document.body.removeChild(ta);
            return ok;
        } catch (e) {
            return false;
        }
    },

    bindCopyDelegation: function () {
        if (window.__kpcAssistantCopyBound) return;
        window.__kpcAssistantCopyBound = true;
        document.addEventListener("click", async function (e) {
            const btn = e.target.closest("[data-copy]");
            if (!btn) return;
            e.preventDefault();
            const text = btn.getAttribute("data-copy") || "";
            const ok = await window.kpcAssistant.copy(text);
            const original = btn.innerHTML;
            btn.innerHTML = ok
                ? '<i class="fa-solid fa-check"></i>'
                : '<i class="fa-solid fa-xmark"></i>';
            btn.classList.add("copied");
            setTimeout(function () {
                btn.innerHTML = original;
                btn.classList.remove("copied");
            }, 1200);
        }, true);
    }
};

