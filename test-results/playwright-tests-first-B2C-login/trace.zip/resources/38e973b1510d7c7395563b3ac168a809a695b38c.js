// https://github.com/skyflowapi/skyflow-js

//Step 2
var composableContainer;
var skyflowClient;
var cardNumber1Element;
var cardCvvElement;

window.createCardForm = async (vaultId, vaultUrl, token) => {
  if (!skyflowClient) {
    skyflowClient = Skyflow.init({
      vaultID: vaultId, // Id of the vault that the client should connect to.
      vaultURL: vaultUrl, // URL of the vault that the client should connect to.
      getBearerToken: () => new Promise((resolve, _) => resolve(token)), // Helper function that retrieves a Skyflow bearer token from your backend.
      options: {
        logLevel: Skyflow.LogLevel.WARN, // Optional, if not specified default is ERROR.
        env: Skyflow.Env.PROD, // Optional, if not specified default is PROD.
      },
    });
  }

  const fontFamily =
    'system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans","Liberation Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji"';

  composableContainer = skyflowClient.container(Skyflow.ContainerType.COLLECT);

  const collectStylesOptions = {
    inputStyles: {
      base: {
        fontFamily,
        fontSize: "14px",
        fontWeight: "normal",
        lineHeight: "21px",
        width: "99%",
        padding: "5px",
        paddingLeft: "10px",
        border: "1px solid #ced4da",
        borderRadius: "4px",
        height: "30px",
      },
      focus: {
        borderColor: "#86b7fe",
        boxShadow: "0 0 0 4px rgba(13,110,253,.25)",
        marginLeft: "5px",
      },
      complete: {
        borderColor: "green",
      },
      invalid: {
        borderColor: "red",
      },
      cardIcon: {
        position: "absolute",
        left: "3px",
        bottom: "calc(50% - 12px)",
      },
    },
    labelStyles: {
      base: {
        fontFamily,
        fontWeight: "500",
        color: "#343a40",
        fontSize: "12px",
      },
      invalid: {
        color: "red",
      },
      requiredAsterisk: {
        color: "transparent",
      },
    },
    errorTextStyles: {
      base: {
        fontFamily,
        fontWeight: "500",
        fontSize: "12px",
      },
    },
  };

  cardNumber1Element = composableContainer.create(
    {
      table: "cards",
      column: "card_number",
      ...collectStylesOptions,
      placeholder: "4111 1111 1111 1111",
      label: "Card Number",
      type: Skyflow.ElementType.CARD_NUMBER,
    },
    { required: true, enableCardIcon: true }
  );

  cardCvvElement = composableContainer.create(
    {
      table: "cards",
      column: "cvv",
      ...collectStylesOptions,
      placeholder: "123",
      label: "CVV",
      type: Skyflow.ElementType.CVV,
    },
    { required: true }
  );
};

window.mountCardForm = async () => {
  cardNumber1Element.mount("#cardNumber");
  cardCvvElement.mount("#cardCvv");
};

window.unmountCardForm = async () => {
  cardNumber1Element.unmount("#cardNumber");
  cardCvvElement.unmount("#cardCvv");
};

window.submitCardInformation = async (month, year, lastUpdate) => {
  var response = null;
  if (composableContainer) {
    try {
      response = await composableContainer.collect({
        tokens: true,
        additionalFields: {
          records: [
            {
              table: "cards", // Table into which record should be inserted.
              fields: {
                expiry_month: month,
                expiry_year: year,
                last_update: lastUpdate,
              },
            },
          ],
        },
        upsert: [
          // Upsert operations support in the vault
          {
            table: "cards", // Table name
            column: "card_number", // Unique column in the table
          },
        ],
      });
    } catch (error) {
      response = { error };
    }
  }
  return response;
};
