window.initializeOutsideClickHandler = (dotNetHelper) => {
    document.addEventListener('click', (event) => {
        const menuElement = document.querySelector('.mobile-menu-open-state');
        if (menuElement && !menuElement.contains(event.target)) {
            dotNetHelper.invokeMethodAsync('CloseMobileMenu');
        }
    });
};