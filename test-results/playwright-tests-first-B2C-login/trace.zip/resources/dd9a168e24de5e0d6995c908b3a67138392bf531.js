// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function downloadFileFromBytes(fileName, bytes, mimeType) {
    const blob = new Blob([bytes], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function initializeInactivityTimer(dotnetHelper) {
    var timer;
    document.onmousemove = resetTimer;
    document.onkeydown = resetTimer;

    function resetTimer() {
        clearTimeout(timer);
        timer = setTimeout(logout, 60000*45)
    }

    function logout() {
        dotnetHelper.invokeMethodAsync("LogoutIsInactive");
    }
}

// Returns the bottom-left viewport coordinates of an element, used to anchor pop-ups (e.g. the grid
// column chooser) directly beneath the button that opened them.
function getElementAnchorPosition(elementId) {
    const el = document.getElementById(elementId);
    if (!el) {
        return { x: 0, y: 0 };
    }
    const rect = el.getBoundingClientRect();
    return { x: Math.round(rect.left), y: Math.round(rect.bottom) };
}

