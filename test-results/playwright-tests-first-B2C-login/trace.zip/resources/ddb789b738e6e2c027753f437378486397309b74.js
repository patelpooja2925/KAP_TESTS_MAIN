window.pageFilterStorage = {
    save: function (key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    },
    load: function (key) {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : null;
    },
    clear: function (key) {
        localStorage.removeItem(key);
    },
    ClearOnPageClosure: function (key, pathPrefix) {
        window.onbeforeunload = function () {
            const currentPath = window.location.pathname;
            if (currentPath.startsWith(pathPrefix)) {
                localStorage.removeItem(key);
            }
        };
    }
};